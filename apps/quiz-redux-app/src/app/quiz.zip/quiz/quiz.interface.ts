export interface Quiz {
  totalQuestions: number;
  current_score: number;
  current_Question_Index: number;
  currentQuestion: string;
  total_score: number;
  questions: Question[];
  options: string[];
  selectedOption: string | null;
  isOptionSelected: boolean;
  selectedOptionClass: string | null;
  correctAnswerClass: string | null;
  userResponses: (string | null)[];
  isFirstQuestion$: boolean;
  correctAnswer: string;
}

// export interface Question {
//   question: string;
//   options: string[];
//   correctAnswer: string;
// }

export interface Question {
  category: string;
  id: string;
  correctAnswer: string;
  incorrectAnswers: string[];
  question: {
    text: string;
  };
  tags: string[];
  type: string;
  difficulty: string;
  regions: string[];
  isNiche: boolean;
  options: string[];
}

export interface category {
  [key: string]: string[];
}
