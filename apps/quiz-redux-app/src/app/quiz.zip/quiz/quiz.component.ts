import { Component, OnInit } from '@angular/core';
import { Question, Quiz } from './quiz.interface';
import { Store, select } from '@ngrx/store';
import { QuizActions } from '../+state/quiz-app.actions';
import { Observable, combineLatest, map, take } from 'rxjs';
import { Router } from '@angular/router';
import {
  selectCorrectAnswer,
  selectCurrentQuestion,
  selectCurrentQuestionIndex,
  selectCurrentScore,
  selectIsOptionCorrect,
  selectIsOptionIncorrect,
  selectIsOptionSelected,
  selectQuestions,
  selectSelectedOption,
  selectTotalQuestions,
  selectUserResponses,
} from '../+state/quiz-app.selectors';

@Component({
  selector: 'quiz-app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.scss'],
})
export class QuizComponent implements OnInit {
  questions$!: Observable<Question[]>;
  currentQuestionIndex$!: Observable<number | null>;
  totalQuestions$!: Observable<number | null>;
  currentQuestion$!: Observable<Question | undefined>;
  correctAnswer$!: Observable<string>;
  currentScore$!: Observable<number>;
  isFirstQuestion$!: Observable<boolean>;
  isLastQuestion$!: Observable<boolean>;
  isOptionSelected = false;
  quizText!: string;
  selectedOption: string | null = null;
  selectedOptionClass: string | null = null;
  correctAnswerClass: string | null = null;
  selectedOptionIndex$!: Observable<number | null>;
  userResponses$!: Observable<(string | null)[]>;

  nextBtn = 'Next';
  // state: Quiz = {
  //   totalQuestions: 0,
  //   current_score: 0,
  //   total_score: 0,
  //   questions: [],
  //   options: [],
  //   currentQuestion: '',
  //   current_Question_Index: 0,
  // };
  // =================today's work ========================
  optionWindowVisible = false;
  sideWindowVisible = false;
  currentQuestion: any;
  selectedOption$!: Observable<string | null>;
  isOptionSelected$!: Observable<boolean>;
  isOptionCorrect$!: Observable<boolean>;
  isOptionIncorrect$!: Observable<boolean>;

  constructor(private store: Store, private router: Router) {}

  ngOnInit(): void {
    this.store.dispatch(QuizActions.loadQuestions());
    this.currentQuestionIndex$ = this.store.pipe(
      select(selectCurrentQuestionIndex),
      map((index) => index + 1)
    );
    this.questions$ = this.store.pipe(select(selectQuestions));
    this.totalQuestions$ = this.store.pipe(select(selectTotalQuestions));
    this.currentQuestion$ = this.store.pipe(select(selectCurrentQuestion));
    this.correctAnswer$ = this.store.pipe(select(selectCorrectAnswer));
    this.currentScore$ = this.store.pipe(select(selectCurrentScore));

    // ===================== new work ==============
    this.selectedOption$ = this.store.select(selectSelectedOption);
    this.isOptionSelected$ = this.store.select(selectIsOptionSelected);
    this.isOptionCorrect$ = this.store.select(selectIsOptionCorrect);
    this.isOptionIncorrect$ = this.store.select(selectIsOptionIncorrect);
    // for previous question
    this.isFirstQuestion$ = this.currentQuestionIndex$.pipe(
      map((index) => index === 1)
    );
    this.userResponses$ = this.store.pipe(select(selectUserResponses));
    this.isLastQuestion$ = combineLatest([
      this.currentQuestionIndex$,
      this.totalQuestions$,
    ]).pipe(
      map(([index, totalQuestions]) => {
        console.log('Total Questions:', totalQuestions);
        const lastQuestion = (index ?? 0) > (totalQuestions ?? 0);
        return lastQuestion;
      })
    );
    // ===============================
    this.store
      .pipe(select(selectSelectedOption))
      .subscribe((selectedOption: string | null) => {
        this.selectedOption = selectedOption;
      });

    // ================================================================
    //this is only to show in console and otherwise not working at all
    this.correctAnswer$.subscribe((correctAnswer) =>
      console.log('Correct Answer:', correctAnswer)
    );
    this.currentQuestionIndex$.subscribe((index) => {
      console.log('Current Question Index:', index);
    });
    this.currentQuestionIndex$.subscribe((index) => {
      if (index && index === 10) {
        this.nextBtn = 'Complete';
      }
    });
  }

  toggleOptionWindow() {
    this.optionWindowVisible = !this.optionWindowVisible;
  }
  openSideWindow() {
    this.sideWindowVisible = true;
  }
  closeSideWindow() {
    this.sideWindowVisible = false;
  }
  setCurrentQuestion(question: any, index: number) {
    this.currentQuestion = question;
    this.store.dispatch(QuizActions.setCurrentQuestion({ question, index }));
  }
  skipQuestion() {
    console.log('skip');
    this.store.dispatch(QuizActions.skipQuestion());
    this.currentQuestionIndex$.subscribe((index) => {
      if (index && index > 10) {
        this.router.navigate(['/skip']);
      }
    });
  }
  nextQuestion() {
    console.log('hello');
    this.store.dispatch(QuizActions.nextQuestion());
    // reset styling
    this.selectedOption = null;
    this.selectedOptionClass = null;
    this.correctAnswerClass = null;
    this.isOptionSelected = false;

    this.currentQuestionIndex$.subscribe((index) => {
      if (index && index > 10) {
        this.router.navigate(['/result']);
      }
    });
  }
  previousQuestion() {
    this.store.dispatch(QuizActions.previousQuestion());
  }

  selectOption(option: string) {
    this.store.dispatch(QuizActions.selectOption({ option }));
  }
}
